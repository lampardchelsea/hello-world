#(a) 
#Set the seed to 20 and draw a random sample of size 30 from the 
#CollegeMidwest.txt data.
set.seed(20)
sample_index <- sample(nrow(college), size = 30)
sample_index
sample_detail <- college[sample_index, ]$CumGpa
sample_detail

#(b)
#Should our t-statistic from (b) be the same as the statistic component 
#of our t.test() output in part (c)?
#yes
#How would you interpret this value?
sample_mean <- mean(sample_detail)
sample_sd <- sd(sample_detail)
observed_t_statistic <- (sample_mean - 3.5) / (sample_sd / sqrt(30))
observed_t_statistic



#(c)
#Use the t.test() function to conduct a one-sample t-test to decide 
# if the true mean cumulative GPA of all the students at the College 
# of the Midwest is different 3.5. Use a significance level of 0.05.
#http://www.sthda.com/english/wiki/one-sample-t-test-in-r
#https://suinotes.wordpress.com/2009/11/30/understanding-t-test-in-r/
t.test(sample_detail, mu = 3.5)

#(d)
class(t.test(sample_detail, mu = 3.5)) #htest
mode(t.test(sample_detail, mu = 3.5)) #list




