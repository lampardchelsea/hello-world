college <- read.table("CollegeMidwest.txt", header = TRUE)
head(college, 3)

#(a)
# Set the seed to 24601, and simulate the sampling distribution of the 
# difference in mean cumulative GPA between the students who live off 
# campus and the students who live on campus. Simulate the difference
# in sample means from 1000 random samples of size 30.
# Hint: The total sample size for each repetition should be 30, not 60.

# We first create objects for common quantities.
n <- 30 # The sample size
N <- nrow(college) # The population size
M <- 1000 # Number of samples/repetitions
# Create vectors to store the simulated proportions from each repetition.
phats <- numeric(M) # for sample proportions
# Set the seed for reproduceability
set.seed(24601)
# Let i cycle over the numbers 1 to M (i.e., iterate M times).
for (i in seq_len(M)) {
  # The i-th iteration of the for loop represents a single repetition.
  # Take a simple random sample of size n from the population of size N.
  index <- sample(N, size = n)
  # Save the random sample in the sample_i vector.
  sample_i <- college[index, ]
  # Compute the difference of mean on i-th sample of students 
  # who live on campus and who live off campus
  on_campus_count <- sum(sample_i$OnCampus == "Y")
  off_campus_count <- sum(sample_i$OnCampus == "N")
  on_campus_total_gpa <- sum(sample_i$CumGpa[sample_i$OnCampus == "Y"])
  off_campus_total_gpa <- sum(sample_i$CumGpa[sample_i$OnCampus == "N"])
  on_campus_gpa_mean <- on_campus_total_gpa / on_campus_count
  off_campus_gpa_mean <- off_campus_total_gpa / off_campus_count
  phats[i] <- on_campus_gpa_mean - off_campus_gpa_mean
}

#(b)
hist(phats,
     prob = TRUE, breaks = 25, xlab = expression(hat(p)),
     main = "Histogram of College Sample Proportions", col = "blue", density = 30
)
abline(v = (mean(phats) + 2 * sd(phats)), lty = 2, col = "red")
abline(v = (mean(phats) - 2 * sd(phats)), lty = 2, col = "red")

#(c)
phats_mean <- mean(phats)
phats_sd <- sd(phats)
curve(dnorm(x, phats_mean, phats_sd), lwd = 2, col = "blue", add = TRUE)

#(d)
probability <- pnorm(1, phats_mean, phats_sd) - pnorm(0.48, phats_mean, phats_sd)
probability



