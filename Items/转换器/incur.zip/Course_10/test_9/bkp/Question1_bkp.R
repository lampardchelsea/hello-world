#(a)
# Your function should be able to compute the reading ease score for an 
# entire text passage if it is inputted as a single character value 
# (i.e., all sentences in a single string) or as a character vector
# (i.e., sentences may be split into separate strings)
# RE = 206.835 − (1.015 × ASL) − (84.6 × ASW) = 96.76339
# ASL -> average sentence length -> totl words / total sentences
# ASW -> average number of syllables per word -> toal syllables / total words
# The primary components of the Flesch reading score formula are: 
# sentences, words, and syllables. The main steps to compute the reading score are:
# 1. Separate the text passage into individual sentences, and count the number of sentences.
# 2. Separate each sentence into individual words, and count the number of words for each sentence.
# 3. Separate each individual word into individual syllables, and count the number of syllables.

reading_ease <- function(x) {
  temp <- strsplit(x, split = "[.!?:;]")
  # Collapsed input chacater vector into one string
  if(length(temp) > 1) {
    collapsed_x <- paste(x, sep="", collapse = " ")
    temp <- strsplit(collapsed_x, split = "[.!?:;]")
  }
  # Get total sentences
  x_sentences <- temp[[1]]
  x_sentences <- tolower(x_sentences)
  total_sentences <- length(x_sentences)
  # Get total words
  x_sentences <- gsub(pattern = "[[:punct:]]", replacement = "", x_sentences)
  x_words <- strsplit(x_sentences, split = " ")
  x_words <- lapply(x_words, keep_words)
  total_words <- length(unlist(x_words))
  # Get ASL
  ASL <- total_words / total_sentences
  # Get total syllables
  total_syllables <- count_total_syllables(x_words)
  # Get ASW
  ASW <- total_syllables / total_words
  # RE = 206.835 − (1.015 × ASL) − (84.6 × ASW)
  206.835 - (1.015 * ASL) - (84.6 * ASW)
}

keep_words <- function(words) {
  words[nchar(words) > 0]
}

count_total_syllables <- function(words) {
  count <- 0
  for(i in seq_len(length(words))) {
    count <- count + sum(unlist(lapply(words[[i]], count_syllables)))
  }
  count
}

count_syllables <- function(word) {
  word_letters <- unlist(strsplit(word, split = ""))
  if (length(word_letters) <= 3) {
    1
  } else {
    word_letters <- rm_special_endings(word_letters)
    word_vowels <- is_vowel(word_letters)
    sum(word_vowels) - sum(diff(which(word_vowels)) == 1)
  }
}

rm_special_endings <- function(word_letters) {
  word_tail <- tail(word_letters, n = 2)
  if (is_special_ending(word_tail)) {
    if (word_tail[2] == "e") {
      word_letters[-length(word_letters)]
    } else {
      head(word_letters, n = -2)
    }
  } else {
    word_letters
  }
}

is_special_ending <- function(ending) {
  is_es <- all(ending == c("e", "s"))
  is_ed <- all(ending == c("e", "d"))
  is_e_not_le <- ending[2] == "e" & ending[1] != "l"
  is_es | is_ed | is_e_not_le
}

is_vowel <- function(letter) {
  letter %in% c("a", "e", "i", "o", "u", "y")
}

source("waffles.R")
waffles
waffles_vec <-
  c("We need to remember what's important in life: friends, waffles, work.",
    "Or waffles, friends, work.",
    "Doesn't matter, but work is third."
  )
reading_ease(waffles)
reading_ease(waffles_vec)





# Remember that the output of strsplit() is always a list. 
# Since the waffles object was a single character
# value, then the output of strsplit(waffles, split = "[.!?:;]") 
# has a single component. To continue
# processing the text, we will extract the character vector inside.
strsplit(waffles, split = "[.!?:;]") # as list as size = 1
waffles
strsplit(waffles_vec, split = "[.!?:;]")
waffles_vec
######################################################################
# 1. To find the individual sentences, we need to split the text string 
# based on “end of sentence” punctuation. The sentence delimiters, i.e., 
# what symbols represent the end of a sentence, we want to consider are periods
# (.), exclamation points (!), question marks (?), colons (:), and semicolons (;).
# To continue processing the text, we will extract the character vector inside.
waffles_sentences <- strsplit(waffles, split = "[.!?:;]")[[1]]
waffles_sentences
# We can thus prepare our sentences for splitting into words by converting 
# all letters to lower case and removing all remaining punctuation.
waffles_sentences <- tolower(waffles_sentences)
waffles_sentences
##########################################################
length(waffles_sentences)
# Get total sentences = 4
##########################################################
waffles_sentences <- gsub(pattern = "[[:punct:]]", replacement = "", waffles_sentences)
waffles_sentences
waffles_words <- strsplit(waffles_sentences, split = " ")
waffles_words
keep_words <- function(words) {
  words[nchar(words) > 0]
}
waffles_words <- lapply(waffles_words, keep_words)
waffles_words
# Get total words = 8 + 3 + 4 + 6 = 21
##########################################################
length(unlist(waffles_words))
# ASL = 21 / 4 = 5.25
##########################################################
# 2. (number of syllables) = (number of vowels) − (number of consecutive differences of 1 in the vowel indices).
count_syllables <- function(word) {
  word_letters <- unlist(strsplit(word, split = ""))
  if (length(word_letters) <= 3) {
    1
  } else {
    word_letters <- rm_special_endings(word_letters)
    word_vowels <- is_vowel(word_letters)
    sum(word_vowels) - sum(diff(which(word_vowels)) == 1)
  }
}

rm_special_endings <- function(word_letters) {
  word_tail <- tail(word_letters, n = 2)
  if (is_special_ending(word_tail)) {
    if (word_tail[2] == "e") {
      word_letters[-length(word_letters)]
    } else {
      head(word_letters, n = -2)
    }
  } else {
    word_letters
  }
}

is_special_ending <- function(ending) {
  is_es <- all(ending == c("e", "s"))
  is_ed <- all(ending == c("e", "d"))
  is_e_not_le <- ending[2] == "e" & ending[1] != "l"
  is_es | is_ed | is_e_not_le
}

is_vowel <- function(letter) {
  letter %in% c("a", "e", "i", "o", "u", "y")
}

#count_syllables("tom")
#count_syllables("horses")
#count_syllables("eagleton")
#count_syllables("pneumonoultramicroscopicsilicovolcanoconiosis")

# apply count_syllables function for all words
total_syllables <- function(words_list) {
  count <- 0
  for(i in seq_len(length(waffles_words))) {
    count <- count + sum(unlist(lapply(waffles_words[[i]], count_syllables)))
  }
  count
}
#seq_len(length(waffles_words))
#waffles_words
count_syllables("we") + count_syllables("need") + count_syllables("to") + count_syllables("remember") + count_syllables("whats") + count_syllables("important") + count_syllables("in") + count_syllables("life")
count_syllables("friends") + count_syllables("waffles") + count_syllables("work")
count_syllables("or") + count_syllables("waffles") + count_syllables("friends") + count_syllables("work")
count_syllables("doesnt") + count_syllables("matter") + count_syllables("but") + count_syllables("work") + count_syllables("is") + count_syllables("third")
total_syllables(waffles_words) # total syllables = 26
#sum(unlist(lapply(waffles_words[[1]], count_syllables)))
##########################################################
# ASW = 26 / 21 = 1.238
##########################################################
# RE = 206.835 − (1.015 × 21 / 4) − (84.6 × 26 / 21) = 96.76339
##########################################################
collapsed_waffles_vec <- paste(waffles_vec, sep="", collapse = " ")
collapsed_waffles_vec

strsplit(collapsed_waffles_vec, split = "[.!?:;]") # as list as size = 3
waffles_vec_sentences <- strsplit(collapsed_waffles_vec, split = "[.!?:;]")[[1]]
waffles_vec_sentences

waffles_vec_sentences <- tolower(waffles_vec_sentences)
waffles_vec_sentences

waffles_vec_sentences <- gsub(pattern = "[[:punct:]]", replacement = "", waffles_vec_sentences)
waffles_vec_sentences
waffles_vec_words <- strsplit(waffles_vec_sentences, split = " ")
waffles_vec_words
keep_words <- function(words) {
  words[nchar(words) > 0]
}
waffles_vec_words <- lapply(waffles_vec_words, keep_words)
waffles_vec_words
length(unlist(waffles_vec_words))

total_syllables(waffles_vec_words) # total syllables = 26