#(a)
reading_ease <- function(x) {
  temp <- strsplit(x, split = "[.!?:;]")
  # Collapsed input chacater vector into one string
  if(length(temp) > 1) {
    collapsed_x <- paste(x, sep="", collapse = " ")
    temp <- strsplit(collapsed_x, split = "[.!?:;]")
  }
  # Get total sentences
  x_sentences <- temp[[1]]
  x_sentences <- tolower(x_sentences)
  total_sentences <- length(x_sentences)
  # Get total words
  x_sentences <- gsub(pattern = "[[:punct:]]", replacement = "", x_sentences)
  x_words <- strsplit(x_sentences, split = " ")
  x_words <- lapply(x_words, keep_words)
  total_words <- length(unlist(x_words))
  # Get ASL
  ASL <- total_words / total_sentences
  # Get total syllables
  total_syllables <- count_total_syllables(x_words)
  # Get ASW
  ASW <- total_syllables / total_words
  # RE = 206.835 − (1.015 × ASL) − (84.6 × ASW)
  206.835 - (1.015 * ASL) - (84.6 * ASW)
}

keep_words <- function(words) {
  words[nchar(words) > 0]
}

count_total_syllables <- function(words) {
  count <- 0
  for(i in seq_len(length(words))) {
    count <- count + sum(unlist(lapply(words[[i]], count_syllables)))
  }
  count
}

count_syllables <- function(word) {
  word_letters <- unlist(strsplit(word, split = ""))
  if (length(word_letters) <= 3) {
    1
  } else {
    word_letters <- rm_special_endings(word_letters)
    word_vowels <- is_vowel(word_letters)
    sum(word_vowels) - sum(diff(which(word_vowels)) == 1)
  }
}

rm_special_endings <- function(word_letters) {
  word_tail <- tail(word_letters, n = 2)
  if (is_special_ending(word_tail)) {
    if (word_tail[2] == "e") {
      word_letters[-length(word_letters)]
    } else {
      head(word_letters, n = -2)
    }
  } else {
    word_letters
  }
}

is_special_ending <- function(ending) {
  is_es <- all(ending == c("e", "s"))
  is_ed <- all(ending == c("e", "d"))
  is_e_not_le <- ending[2] == "e" & ending[1] != "l"
  is_es | is_ed | is_e_not_le
}

is_vowel <- function(letter) {
  letter %in% c("a", "e", "i", "o", "u", "y")
}

source("waffles.R")
waffles
waffles_vec <-
  c("We need to remember what's important in life: friends, waffles, work.",
    "Or waffles, friends, work.",
    "Doesn't matter, but work is third."
  )
waffles_vec
reading_ease(waffles)
reading_ease(waffles_vec)