waffles <-
"We need to remember what's important in life: friends, waffles, work. Or waffles, friends, work. Doesn't matter, but work is third."