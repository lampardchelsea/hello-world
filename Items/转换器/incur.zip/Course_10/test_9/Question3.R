#(a) 
#Set the seed to 20 and draw a random sample of size 30 from the 
#CollegeMidwest.txt data.
set.seed(20)
sample_index <- sample(nrow(college), size = 30)
sample_index
sample_detail <- college[sample_index, ]$CumGpa
sample_detail

#(b)
#Should our t-statistic from (b) be the same as the statistic component 
#of our t.test() output in part (c)?
#yes
sample_mean <- mean(sample_detail)
sample_sd <- sd(sample_detail)
observed_t_statistic <- (sample_mean - 3.5) / (sample_sd / sqrt(30))
observed_t_statistic
#How would you interpret this value?
#A test statistic is a standardized value that is calculated from sample 
#data during a hypothesis test. The procedure that calculates the test 
#statistic compares your data to what is expected under the null hypothesis.

#(c)
#Use the t.test() function to conduct a one-sample t-test to decide 
# if the true mean cumulative GPA of all the students at the College 
# of the Midwest is different 3.5. Use a significance level of 0.05.
#http://www.sthda.com/english/wiki/one-sample-t-test-in-r
#https://suinotes.wordpress.com/2009/11/30/understanding-t-test-in-r/
t_test_result <- t.test(sample_detail, mu = 3.5, conf.level = 0.95)
t_test_result
# Statistical significance is determined by looking at the p-value. 
# The p-value gives the probability of observing the test results 
# under the null hypothesis. The lower the p-value, the lower the 
# probability of obtaining a result like the one that was observed 
# if the null hypothesis was true. Thus, a low p-value indicates 
# decreased support for the null hypothesis. 
# From the `t_test_result` we can see p-value = 0.005534, an extremely 
# lower value than desired significance level as 0.5 and not support 
# the null hypothesis as GPA = 3.5, so the true mean cumulative GPA 
# of all the students at the College of the Midwest is different than 3.5


#(d)
#What is the mode and class of the output of t.test() from (c)? 
# Use this information to extract the 95% confidence interval vector 
# from the t.test() output object. Is 3.5 inside this interval? What does
# this say about whether the true mean cumulative GPA is 3.5 or not?
class(t_test_result) #htest
mode(t_test_result) #list
t_test_result$conf.int
#3.5 not in this vector, and this means the true mean cumulative GPA 
#is not 3.5
