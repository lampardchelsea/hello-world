#(a)
n <- 30
N <- nrow(college)
M <- 10000
result <- matrix(0, nrow = 10000, ncol = 2)
set.seed(9999)
for(i in seq_len(M)) {
  sample_idx <- sample(N, size = n)
  sample_data <- college[sample_idx, ]
  sample_cumgpa_mean <- mean(sample_data$CumGpa)
  result[i, ] <- t.test(sample_data$CumGpa, mu = sample_cumgpa_mean, conf.level = 0.95)$conf.int
}
result[1:6, ]

#(b)
all_population_gpamean <- mean(college$CumGpa)
all_population_gpamean
test_mean <- function(x) {
  if(all_population_gpamean >= x[1] && all_population_gpamean <= x[2]) {
    1
  } else {
    0
  }
}
mean(apply(result, 1, test_mean)) #0.9432
# Is this proportion consistent with what you expected?
# Yes, this proportion consistent with what i expected, 
# because 0.9432 approximately to what we expected as
# confidence interval as 0.95, which also means the true
# mean should come from confidence interval.

#(c)
replicates <- 100
confint <- result[1:100, ]
plot(c(all_population_gpamean, all_population_gpamean), c(1, replicates), col = "blue", typ = "l",
     ylab = "Samples",
     xlab = "Confidence Interval")
segments(confint[, 1], 1:replicates, confint[, 2], 1:replicates)

# Use red color line if mean outside confident interval
outside <- ifelse(confint[, 1] > all_population_gpamean | confint[, 2] < all_population_gpamean, 2, 1)
plot(c(all_population_gpamean, all_population_gpamean), c(1, replicates), col = "blue", typ = "l",
     ylab = "Samples",
     xlab = "Confidence Interval")
segments(confint[, 1], 1:replicates, confint[, 2], 1:replicates, col = outside)

# Add a legend
legend("topleft", cex = 0.55,
       legend = c("truemean", "interval truemean inside", 
                  "interval truemean outside"),
       col = c("blue", "black", "red"),
       text.col = c("blue", "black", "red"),
       lty = c(1, 1, 1),
       title = "GPA interval")

w


