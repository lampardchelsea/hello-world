source("waffles.R")
waffles

waffles_sentences <- strsplit(waffles, split = "[.!?:;]")[[1]]
waffles_sentences

waffles_sentences <- tolower(waffles_sentences)
waffles_sentences

waffles_sentences <- gsub(pattern = "[[:punct:]]", replacement = "", waffles_sentences)
waffles_sentences

waffles_words <- strsplit(waffles_sentences, split = " ")
waffles_words

keep_words <- function(words) {
  words[nchar(words) > 0]
}
waffles_words <- lapply(waffles_words, keep_words)
waffles_words

strsplit("tom", split = "")
unlist(strsplit("tom", split = ""))

tom_letters <- unlist(strsplit("tom", split = ""))
tom_letters

horses_letters <- unlist(strsplit("horses", split = ""))
horses_letters

eagleton_letters <- unlist(strsplit("eagleton", split = ""))
eagleton_letters

horses_tail <- tail(horses_letters, n = 2)
horses_tail
is_special_ending <- function(ending) {
  is_es <- all(ending == c("e", "s"))
  is_ed <- all(ending == c("e", "d"))
  is_e_not_le <- ending[2] == "e" & ending[1] != "l"
  is_es | is_ed | is_e_not_le
}
is_special_ending(horses_tail)

rm_special_endings <- function(word_letters) {
  word_tail <- tail(word_letters, n = 2)
  if (is_special_ending(word_tail)) {
    if (word_tail[2] == "e") {
      word_letters[-length(word_letters)]
    } else {
      head(word_letters, n = -2)
    }
  } else {
    word_letters
  }
}
rm_special_endings(horses_letters)

is_vowel <- function(letter) {
  letter %in% c("a", "e", "i", "o", "u", "y")
}
eagleton_vowels <- is_vowel(eagleton_letters)
eagleton_vowels
which(eagleton_vowels)
diff(which(eagleton_vowels))

count_syllables <- function(word) {
  word_letters <- unlist(strsplit(word, split = ""))
  if (length(word_letters) <= 3) {
    1
  } else {
    word_letters <- rm_special_endings(word_letters)
    word_vowels <- is_vowel(word_letters)
    sum(word_vowels) - sum(diff(which(word_vowels)) == 1)
  }
}

count_syllables("tom")
count_syllables("horses")
count_syllables("eagleton")
count_syllables("pneumonoultramicroscopicsilicovolcanoconiosis")

reading_ease(waffles)


set.seed(20)
sample(1:10)


waffles_vec <-
  c("We need to remember what's important in life: friends, waffles, work.",
    "Or waffles, friends, work.",
    "Doesn't matter, but work is third."
  )

strsplit(waffles_vec, split = "[.!?:;]")

collapsed_waffles_vec <- paste(waffles_vec, sep="", collapse = " ")
collapsed_waffles_vec

collapsed_waffles_vec

set.seed(24601)
sample_index <- sample(2919, size = 30)
sample_index
sample_i <- college[sample_index, ]
sample_i
typeof(sample_i) #list
on_campus_total_gpa <- 0
off_campus_total_gpa <- 0
for(i in 1:30) {
  if(sample_i[i, ]$OnCampus == "Y") {
    on_campus_total_gpa <- on_campus_total_gpa + sample_i[i, ]$CumGpa
  } else {
    off_campus_total_gpa <- off_campus_total_gpa + sample_i[i, ]$CumGpa
  }
}
#on_campus_total_gpa
#off_campus_total_gpa
on_campus_count <- sum(sample_i$OnCampus == "Y")
off_campus_count <- sum(sample_i$OnCampus == "N")
sum(sample_i$CumGpa[sample_i$OnCampus == "Y"])
sum(sample_i$CumGpa[sample_i$OnCampus == "N"])


if(sample_i$OnCampus == "Y") {
  on_campus_total_gpa <- on_campus_total_gpa + sample_i$CumGpa
}
on_campus_total_gpa

sample_i[1, ]$OnCampus == "Y"
sample_i[1, ]$CumGpa


college <- read.table("http://www.math.hope.edu/isi/data/chap3/CollegeMidwest.txt",header = T)

set.seed(9999)
sims <- matrix(0,nrow =2,ncol = 10000)
for(i in 1:10000){
  sample.index <- sample(nrow(college),size = 30)
  sample.std <- college[sample.index,] #Select a random sample of 30 students.
  mu.sample <- mean(sample.std$CumGpa) #Compute the mean cumulative GPA
  sims[,i] <- t.test(sample.std$CumGpa,mu = mu.sample)$conf.int
}
sims[,1:10]

truemean <- mean(college$CumGpa)
mean(apply(sims,2,function(x){ifelse(truemean >= x[1] && truemean <= x[2],1,0)}))


samsize <- 100 
replicates <- 50
pval <- .05

samples <- replicate(replicates, rnorm(samsize))
confint <- t(apply(samples, 2, function(x)
  c(mean(x)-qt(1-pval/2, df=samsize-1)*sd(x)/sqrt(samsize), 
    mean(x)+qt(1-pval/2, df=samsize-1)*sd(x)/sqrt(samsize))))

# Simple plot
plot(c(0, 0), c(1, replicates), col="black", typ="l", ylab="Samples", xlab="Confidence Interval")
segments(confint[,1], 1:replicates, confint[,2], 1:replicates)

# Use red if mean outside interval
outside <- ifelse(confint[,1]>0 | confint[,2]<0, 2, 1)
plot(c(0, 0), c(1, replicates), col="black", typ="l",
     ylab="Samples",
     xlab="Confidence Interval")
segments(confint[,1], 1:replicates, confint[,2], 1:replicates,
         col=outside)




"This is the 'R' Language"
"This is the \"R\" Language"

paste("I ate some", pi, "and it was deloicious.")
paste("Bears", "Beets", "Battlestar Galactica", sep=", ")
paste("h", c("a", "e", "o"), sep = "")
paste("h", c("a", "e", "o"), sep = "", collapse = ", and ")

x <- "aaa"
print(x, quote = TRUE)

cat(x, "Eagleton drools", sep = "|")
cat(x, "Eagleton drools", sep=", ", file = "pawnee.txt")

y <- "Quan Zhang"
z <- "QUAN ZHANG"
if(toupper(y) == z) {
  print("equal")
} else {
  print("not equal")
}


casefold(y, upper = TRUE)
y <- c("Pawnee rules", "Eagleton drools", "Quan Zhang")
substr(y, start = 3, stop = 5)

y <- c("Quan & Zhang", "Yu & Fei")
strsplit(y, split = "&")
strsplit(y, split = " & ")
unlist(strsplit(y, split = " & "))
class(unlist(strsplit(y, split = " & ")))

x <- "Quan"
y <- c("Quan result, fxl", "uan, DFS")
x %in% y


class(letters)
mode(letters)

test <- c("April", "and", "Andy", "love", "Champion", "and", "Lil'", "Sebastian")
gsub("an", "xxx", test)

source("waffles.R")
waffles

waffles_vec <-
  c("We need to remember what's important in life: friends, waffles, work.",
    "Or waffles, friends, work.",
    "Doesn't matter, but work is third."
  )

waffles

x <- strsplit(waffles_vec, split = "[.!?:;]")
collapsed_x <- paste(x, sep="", collapse = " ")
collapsed_x
temp <- strsplit(collapsed_x, split = "[.!?:;]")
temp


strsplit(waffles, split = "[[:punct:]]")[[1]]

z <- ""
nchar("")

keep_words <- function(words) {
  words[nchar(words) > 0]
}
waffles_sentences <- strsplit(waffles, split = "[.!?:;]")[[1]]
waffles_sentences
waffles_sentences <- tolower(waffles_sentences)
waffles_sentences
waffles_sentences <- gsub(pattern = "[[:punct:]]", replacement = "", waffles_sentences)
waffles_sentences
waffles_words <- strsplit(waffles_sentences, split = " ")
waffles_words
waffles_words <- lapply(waffles_words, keep_words)
waffles_words

set.seed(9999)
winning <- c(sample(70, size = 5), sample(25, size = 1))
winning
all(winning > 20)

all_over_20 <- logical(10000)
all_over_20

all_over_20[i]

mean()


