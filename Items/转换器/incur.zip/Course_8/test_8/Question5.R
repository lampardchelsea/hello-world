#(a)
color_cut_diamonds <- with(diamonds, tapply(price, list(color, cut), mean))
color_cut_diamonds

#(b)
#matplot(color_cut_diamonds, type="b", col = 17:22, lty = 1:5, pch = 15, lwd = c(1,1.5,2,2.5,3))
#levels(diamonds$color)
matplot(color_cut_diamonds, xaxt = "n", type="b", col = 17:22, lty = 1:5, pch = 15, lwd = c(1,1.5,2,2.5,3))
x_labels <- c("D", "E", "F", "G", "H", "I", "J")
axis(side = 1, at = 1:length(x_labels), labels = x_labels)
par(mar = c(5.1, 4.1, 4.1, 8.1), xpd = TRUE)
legend("topleft", inset = c(0, -0.305), 
       legend = c("Fair", "Good", "Very Good", "Premium", "Ideal"),
       col = 17:22,
       text.col = 17:22,
       lty = 1:5,
       title = "Diamond Cut")

#(c)
#Yes, Yes, for color J has highest price, for cut Premium has highest price