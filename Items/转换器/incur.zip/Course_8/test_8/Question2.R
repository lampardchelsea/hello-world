# Make histogram for full term baby weights
with(droplevels_births, hist(weight[Habit == "NonSmoker"],
                  prob = TRUE, density = 20, col = "red",
                  xlab = "Weight of born baby depends on smoker or nonsmoker mom", main = "Histogram of Weight by Habit",
                  xlim = range(weight), ylim = c(0, 0.03)))
with(droplevels_births, lines(density(weight[Habit == "NonSmoker"]), lwd = 2, col = "red"))
#lines(density(droplevels_births$weight[droplevels_births$Habit == "NonSmoker"]), lwd = 2, col = "red")

#with(droplevels_births, abline(v = summary(weight[Habit == "NonSmoker"])[c(2, 5)], lty = 2, col = "red"))
with(droplevels_births, abline(v = median(weight[Habit == "NonSmoker"]), lty = 2, col = "red"))



# Add histogram for premature baby weights
with(droplevels_births, hist(weight[Habit == "Smoker"],
                             prob = TRUE, density = 30, col = "blue", add = TRUE))
with(droplevels_births, lines(density(weight[Habit == "Smoker"]), lwd = 2, col = "blue"))
with(droplevels_births, abline(v = median(weight[Habit == "Smoker"]), lty = 2, col = "blue"))



# Add a legend
legend("topleft", c("Nonsmoke distributions", "Smoke distributions", 
                    "Nonsmoke density curves", "Smoke density curves", 
                    "Nonsmoke median", "Smoke median"),
       bty = "n",
       text.col = c("red", "blue", "red", "blue", "red", "blue"),
       col = c("red", "blue", "red", "blue", "red", "blue"),
       density = c(20, 30, 0, 0, 0, 0),
       border = c("red", "blue", NA, NA, NA, NA), 
       lty = c(NA, NA, 1, 1, 2, 2),
       fill = c("red", "blue", "red", "blue", "red", "blue")
)


# legend("topleft", c("box1", "box2", "line1", "line2", "line3", "line4"),
#        col = c("red", "blue", "red", "blue", "red", "blue"),
#        density = c(20, 30, 0, 0, 0, 0),
#        border = c("red", "blue", NA, NA, NA, NA), 
#        lty = c(NA, NA, 1, 1, 2, 2),
#        fill = c("red", "blue", "red", "blue", "red", "blue")
# )

#Based on the plot, do you think there is a significant difference between the typical weight of a baby born to
#a mother who smokes and the typical weight of a baby born to a mother who does not smoke?
#No