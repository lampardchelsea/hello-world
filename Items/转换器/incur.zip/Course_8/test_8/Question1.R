#(a)
births <- read.csv("births.csv")
dim(births)
head(births)


#(b)
levels(births$Habit)
#levels(factor(births$Habit))
#[1] ""          "NonSmoker" "Smoker"
sum(births$Habit == "")
#6

#(c)
smoke_habit <- table(births$Habit)
smoke_habit
barplot(smoke_habit, col = "blue")

#(d)
toBeKept <- births$Habit != ""
smoker_nonsmoker_data <- births[toBeKept, ]
#levels(smoker_nonsmoker_data$Habit)
#dim(smoker_nonsmoker_data)
#dim(births)
droplevels_births <- droplevels(smoker_nonsmoker_data)
levels(droplevels_births$Habit)


#(e)
boxplot(droplevels_births$weight ~ droplevels_births$Habit)


