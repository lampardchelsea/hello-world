library(ggplot2)
data("diamonds")
diamonds


#(a)
#diamonds$carat, diamonds$depth, diamonds$table, diamonds$price
#plot(diamonds$carat ~ diamonds$depth)
plot(carat ~ depth, diamonds)
plot(depth ~ carat, diamonds)
#plot(diamonds$carat ~ diamonds$table)
plot(carat ~ table, diamonds)
plot(table ~ carat, diamonds)
#plot(diamonds$carat ~ diamonds$price)
plot(carat ~ price, diamonds)
plot(price ~ carat, diamonds)
plot(log(price) ~ log(carat), diamonds)
#plot(diamonds$depth ~ diamonds$table)
plot(depth ~ table, diamonds)
plot(table ~ depth, diamonds)
#plot(diamonds$depth ~ diamonds$price)
plot(depth ~ price, diamonds)
plot(price ~ depth, diamonds)
#plot(diamonds$table ~ diamonds$price)
plot(table ~ price, diamonds)
plot(price ~ table, diamonds)

#pairs(diamonds)
pairs(diamonds[, c("carat", "depth", "table", "price")])

# pirce and carat, the relation is non-linear, log(price) and log(carat)

#(b)
#plot(price ~ carat, diamonds, col = clarity)
plot(price ~ carat, diamonds, col = clarity, cex = 0.4, pch = 16)

legend("topright", c("I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"),
       bty = "n",
       title = 'Clarity',
       text.col = c(col = 1, col = 2, col = 3, col = 4, col = 5, col = 6, col = 7, col = 8),
       col = c(col = 1, col = 2, col = 3, col = 4, col = 5, col = 6, col = 7, col = 8),
       pch = c(16,16,16,16,16,16,16,16),
       #density = c(0, 0, 0, 0, 0, 0, 0, 0),
       #border = c("red", "blue", NA, NA, NA, NA), 
       #lty = c(NA, NA, 1, 1, 2, 2),
       #fill = c(col = 1, col = 2, col = 3, col = 4, col = 5, col = 6, col = 7, col = 8)
)

#class(diamonds$clarity)
#levels(diamonds$clarity)
# because there are 8 levels as "I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"
# from clarity, each level should using one color, that's why the default colors 
# of 1 to 8 are chosen


#(c)
select_colors <- c(col = "gray8", col = "red1", col = "limegreen", col = "blue1", 
                   col = "cyan", col = "darkorchid1", col = "yellow2", col = "wheat3")
plot(price ~ carat, diamonds, col = select_colors, cex = 0.4, pch = 16)

legend("topright", c("I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"),
       bty = "n",
       title = 'Clarity',
       text.col = select_colors,
       col = select_colors,
       pch = c(16,16,16,16,16,16,16,16),
       #density = c(0, 0, 0, 0, 0, 0, 0, 0),
       #border = c("red", "blue", NA, NA, NA, NA), 
       #lty = c(NA, NA, 1, 1, 2, 2),
       #fill = c(col = 1, col = 2, col = 3, col = 4, col = 5, col = 6, col = 7, col = 8)
)

#(d)
# Find the three way relation between price, carat, clarity
# log relation between price and carat
select_colors <- c("darkblue", "blue2", "cornflowerblue", "deepskyblue1", "green3", "chartreuse", "goldenrod2", "goldenrod4")
plot(log(price) ~ log(carat), diamonds, col = select_colors, cex = 0.4)
# We can see what looks like an almost linear relationship between carat weight and price 
# after the transformations, However, there are other factors that influence the price of 
# a diamond. Clarity also factors into price. However, people commonly search for a diamond 
# of a specific size, so we shouldn’t expect clarity to be as strong a factor as size (carat).

# https://rstudio-pubs-static.s3.amazonaws.com/211979_60432c2480574f419f646c9834768a77.html
#Clarity and Price
#Response: Clarity does explain some of the change in price because it is clear 
#that diamonds that are “IF” are the most expensive whereas “I1” are the least 
#expensive clarity types. In other words, holding carat weight constant, we see 
#that diamonds with lower clarity are almost always cheaper than diamonds 
#with better clarity. Clarity explains a lot of the variance found in price!

# https://rstudio-pubs-static.s3.amazonaws.com/94067_d1fdfafd20b14725a2578647031760c2.html
#It’s clear that Clarity factors into the diamond price - a better clarity almost 
#always has higher price than lower end clarity.

