#(a)
curve(sin) # x from 0 to 1 as default
curve(sin, 0, 4 * pi)

#(b)
# The sampling for default n = 101 is smaller, increasing n number
# to 1500
curve(sin, 0, 49 * pi, n = 1500)

#(c)
# https://thomasleeper.com/Rcourse/Tutorials/curve.html
# https://stackoverflow.com/questions/42649126/how-to-specify-line-thickness-in-points-in-an-r-plot
curve(sin, 0, 10 * pi, n = 1500, lwd = 1.5)

#(d)
curve(cos, 0, 10 * pi, n = 1500, lwd = 1.5, add = TRUE, lty = 2, col = "red")

#(e)
sin_func <- function(x) {sin(x + pi / 2)}
curve(sin_func, 0, 10 * pi, n = 1500, lwd = 1.5, add = TRUE, lty = 3, col = "blue")
# the curve line of (e) as sin(x + pi / 2) overlapping on the curve line of (d)
# as cos(), for each evaluating point n, the result is same.

