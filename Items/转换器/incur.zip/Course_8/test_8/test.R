trees
hist(trees$Girth)
hist(trees$Girth, xlab = "Quan", ylab = "Zhang", main = "Test111", density = 50, breaks = 10)
length(trees$Girth)
log2(31) + 1

hist(
        trees$Girth,
        breaks = 10,
        freq = FALSE,
        xlim = c(5, 25),
        density = 50,
        col = c("blue", "goldenrod"),
        xlab = "Girth of Black Cherry Trees",
        main = "Histogram of Girth of Black \nCherry Trees"
)



hist(trees$Girth, breaks = "Scott")
hist(trees$Girth, xlim = c(2, 25), xlab = "test", main = "test1", col=4)

births <- read.csv("births.csv")
boxplot(births$weight, horizontal = TRUE)
boxplot(trees)
boxplot(births$weight ~ births$Premie)
boxplot(weight ~ Premie, data = births)
boxplot(weight ~ Premie)

library(ggplot2) # Load ggplot2 package
data(diamonds) # Load diamonds data
diamonds_table <- with(diamonds, table(cut, color)) # Create two-way table of cut and color
diamonds_table
barplot(diamonds_table)
barplot(diamonds_table, beside = TRUE)
barplot(diamonds_table, density = 40, col = 1:5)
barplot(diamonds_table, legend = TRUE, density = 40, col = 1:5)

plot(trees$Height, trees$Girth)
plot(trees$Height ~ trees$Girth)
plot(trees$Girth ~ trees$Height)
plot(Girth ~ Height, data = trees)
plot((1:10)^2)
plot((1:10)^2, type = "n")
plot((1:10)^2, type = "l")
plot((1:10)^2, type = "b", pch = 2, cex = 1.3, col = "blue")

pairs(trees)
plot(trees)

plot(Girth ~ Height, data = trees)
points(c(65, 70, 75), c(12, 17, 20), pch = 4, col = "red", cex = 1.5)

coords_mat <- cbind(c(65, 70, 75), c(12, 17, 20))
coords_mat
plot(Girth ~ Height, data = trees)
points(coords_mat, type = "b", pch = 5, col = "purple", cex = 1.5)

# Find the observations (trees) with an above average (mean) volume
volume_index <- with(trees, Volume > mean(Volume))
# Plot the tree girths against height
plot(Girth ~ Height, data = trees)
# Add a blue + to the observations with an above average volume
points(Girth ~ Height, data = trees[volume_index, ], pch = "+", col = "blue", cex = 1.5)

plot(Girth ~ Height, data = trees)
lines(coords_mat, col = "purple")

plot(Girth ~ Height, data = trees)
lines(Girth ~ Height, data = trees[volume_index, ], col = "green", lty = 2, lwd = 3)

hist(trees$Girth, prob = TRUE)
lines(density(trees$Girth), lwd = 2, col = "blue")

plot((1:10)^2)
text(5, 40, "y = x^2")

plot((1:10)^2)
text(5, 40, expression(y == x^2)) # The double equal sign is needed to print = on the plot

plot((1:10)^2, ylim = c(0, 108)) # Increase ylim to fit text
text(1:10, (1:10)^2 + 5, 1:10, cex = 1.5, col = "blue")

hist(trees$Girth)
locator(2) # Click on two points on the histogram

plot((1:10)^2, xlim = c(0, 10)) # Change the xlim to see the y-intercept at (0,0)
abline(0, 10)
abline(2, 8)

plot((1:10)^2, xlim = c(0, 10))
abline(0, 10, col = "red", lty = 3, lwd = 2.5)

plot((1:10)^2, xlim = c(0, 10))
abline(0, 10, col = "red", lty = 3, lwd = 2.5)
abline(h = 50, lty = 2, col = "blue")
abline(v = 5, lty = 4, col = "green")

plot((1:10)^2, xlim = c(0, 10))
abline(h = seq(0, 100, by = 20), lty = 2, col = "blue")
abline(v = seq(0, 10, by = 2), lty = 2, col = "blue")

# Fit a linear model of Girth by Height
lm_trees <- lm(Girth ~ Height, data = trees)
lm_trees
class(lm_trees)
## [1] "lm"
mode(lm_trees)
## [1] "list"
# Construct a scatterplot of Girth by Height
# Optional argument bg = fill color for pch = 21 through 25
plot(Girth ~ Height, data = trees, pch = 21, bg = "grey")
# Superimpose the regression line
abline(lm_trees, col = "blue")
summary(lm_trees)

hist(trees$Girth, prob = TRUE)
# Superimpose a density curve
lines(density(trees$Girth), lwd = 2, col = "blue")
# Add lines for the first and third quartiles to denote the IQR
abline(v = summary(trees$Girth)[c(2, 5)], lty = 2, col = "red")
# Add a legend with two entries
legend("topright", c("Density Estimate", "IQR"),
       col = c("blue", "red"),
       lty = c(1, 2), lwd = c(2, 1), inset = 0.05
)

# Make histogram for full term baby weights
with(births, hist(weight[Premie == "No"],
                  prob = TRUE, density = 20, col = "red",
                  xlab = "Weight (in ounces)", main = "Histogram of Weight by Premie",
                  xlim = range(weight), ylim = c(0, 0.03)
))
# Add histogram for premature baby weights
with(births, hist(weight[Premie == "Yes"],
                  prob = TRUE, density = 30, col = "blue",
                  breaks = 20, add = TRUE
))
# Add a legend
legend("topleft", c("Full Term", "Premie"),
       density = c(20, 30),
       fill = c("red", "blue"),
       inset = 0.05
)

windows()

# Open a file device in the births-boxplots.pdf file
pdf("births-boxplots.pdf")
# Construct side-by-side boxplots of weight by Premie
boxplot(weight ~ Premie, data = births)
# Close the PDF file device
dev.off()


hist(trees$Girth)
locator(1) # Click on two points on the histogram

lm_trees <- lm(Girth ~ Height, data = trees)
class(lm_trees)
lm_trees

summary(lm_trees)

summary(trees$Girth)[c(2, 5)]
class(trees)
class(trees$Girth)
mode(trees$Girth)


with(births, hist(weight[Premie == "No"],
                  prob = TRUE, density = 20, col = "red",
                  xlab = "Weight (in ounces)", main = "Histogram of Weight by Premie",
                  xlim = range(weight), ylim = c(0, 0.03)
                  
))
with(births, hist(weight[Premie == "Yes"],
                  prob = TRUE, density = 30, col = "blue",
                  breaks = 20, add = TRUE
))
# Add a legend
legend("topleft", c("Full Term", "Premie"),
       density = c(20, 30),
       fill = c("red", "blue"),
       #col = c("red", "blue"),
       inset = 0.05
)

curve(dnorm,
      from = -4, to = 1.5, type = "h", col = "goldenrod",
      10,
      xlim = c(-4, 4), ylab = "dnorm(x, mean, sd)", xaxt = "n"
)
# Add the dnorm(x, 0, 1) curve in blue.
curve(dnorm, from = -4, to = 4, lwd = 2, col = "blue", add = TRUE)
# Add a horizontal line segment at q (q = 1.5 for illustration purposes).
segments(1.5, -1, 1.5, dnorm(1.5), lty = 2)
# Add the label "q" on the x-axis at x = 1.5.
axis(1, at = 1.5, labels = "q")
# Add text to explain that the shaded region is pnorm(q, mean, sd).
text(0, dnorm(0) / 3, "pnorm(q, mean, sd)")

