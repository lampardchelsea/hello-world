library(plyr)
library(dplyr)
library(car)
library(readr)
library(mice)
library(stringr)
library(corrplot)

#load training data
Fifa <- read_csv("/Users/zixiangpei/Desktop/FifaTrainNew.csv")
sum(is.na(Fifa))

#load test data
FifaNoY <- read_csv("/Users/zixiangpei/Desktop/FifaNoY.csv")

#impute data and get rid of NAs
names(Fifa)<-str_replace_all(names(Fifa), c(" " = "." , "," = "" ))
imputed.data <- mice(Fifa)
imputed.data
Fifadata<-complete(imputed.data,2)
#FifadataNew <- Fifadata[complete.cases(Fifadata[ , "Crossing"]),]

#Transform varible
summary(powerTransform(cbind(Fifadata$WageNew, Fifadata$Overall,Fifadata$Age, Fifadata$Potential)~1))
sum(is.na(Fifadata))
dim(Fifadata)

#Early Try
kaggle<-lm(log(Fifadata$WageNew) ~ Fifadata$Overall^2  + Fifadata$Club)
summary(kaggle)

kaggle3<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential + 1/(Age^2),data=Fifadata)
summary(kaggle3)
anova(kaggle3)

#Output
names(FifaNoY)<-str_replace_all(names(FifaNoY), c(" " = "." , "," = "" ))

kaggle0<-lm(log(WageNew) ~ Overall^2 , data=Fifadata)
xsub <- exp(predict(kaggle0,FifaNoY))
x<- exp(predict(kaggle3, FifaNoY))
x<-ifelse(is.na(x), xsub, x)
#write.csv(x, "Desktop/sxc.csv")

