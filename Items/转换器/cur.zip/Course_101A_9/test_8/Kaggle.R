library(plyr)
library(dplyr)
library(car)
library(readr)
library(mice)
library(stringr)
library(corrplot)

#load training data
Fifa <- read_csv("FifaTrainNew.csv")
sum(is.na(Fifa))

#load test data
FifaNoY <- read_csv("FifaNoY.csv")

#impute data and get rid of NAs
names(Fifa)<-str_replace_all(names(Fifa), c(" " = "." , "," = "" ))
imputed.data <- mice(Fifa)
imputed.data
Fifadata<-complete(imputed.data,2)
FifadataNew <- Fifadata[complete.cases(Fifadata[ , "Crossing"]),]

#Transform varible
summary(powerTransform(cbind(Fifadata$WageNew, Fifadata$Overall,Fifadata$Age, Fifadata$Potential)~1))
sum(is.na(Fifadata))
dim(Fifadata)

#Early Try
kaggle<-lm(log(Fifadata$WageNew) ~ Fifadata$Overall^2  + Fifadata$Club)
summary(kaggle)

#Get rid of Outliers and bad leverage
hatval <- hatvalues(kaggle)
badleverage <- which(hatval > 2*3/length(hatval) & abs(rstandard(kaggle)) > 2)
NoBL <- Fifadata[-badleverage,]

#Late Try
kaggle2<-lm(log(NoBL$WageNew) ~ NoBL$Overall^2 + NoBL$Club + NoBL$International.Reputation)
summary(kaggle2)
anova(kaggle2)
sums <- rowSums(FifadataNew[,47:80])

kaggle3<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential + 1/(Age^2),data=Fifadata)
summary(kaggle3)
anova(kaggle3)

#Output
names(FifaNoY)<-str_replace_all(names(FifaNoY), c(" " = "." , "," = "" ))

kaggle0<-lm(log(WageNew) ~ Overall^2 , data=Fifadata)
summary(kaggle0)
xsub <- exp(predict(kaggle0,FifaNoY))
x<- exp(predict(kaggle3, FifaNoY))
x<-ifelse(is.na(x), xsub, x)
write.csv(x, "sxc.csv")


kaggle4<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential 
            + Weak.Foot + Skill.Moves + Special + Weight + Height + Work.Rate 
            + Nationality + Real.Face + Position + 1/(Age^2) + Joined, data = NoBL)
summary(kaggle4)
anova(kaggle4)


kaggle5<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential 
            + Weak.Foot + Skill.Moves + Special + Weight + Height + Work.Rate 
            + Nationality + Real.Face + Position + 1/(Age^2) + Joined + Contract.Valid.Until, data = NoBL)
summary(kaggle5)



