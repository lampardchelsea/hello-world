library(agricolae)

grp <- c(1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4)

y <- c(143,141,150,146,152,149,137,143,134,136,132,127,129,127,132,129)

grp<-factor(grp)

mydata <- data.frame(grp,y)

aov1<-aov(y~grp,data = mydata)

summary(aov1)

res <- aov1$residuals

fitted <- aov1$fitted.values

par(mfrow=c(2,2))

plot(aov1)

par(mfrow=c(1,2))

qqnorm(res)

qqline(res)

plot(fitted, res)

################################################

mydata$grp.means[]


