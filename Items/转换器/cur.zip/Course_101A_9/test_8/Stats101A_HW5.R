library(plyr)
library(dplyr)
library(car)
library(readr)
library(mice)
library(stringr)
library(corrplot)
library(leaps)

#load training data
Fifa <- read_csv("FifaTrainNew.csv")
sum(is.na(Fifa))

#load test data
FifaNoY <- read_csv("FifaNoY.csv")

#impute data and get rid of NAs
names(Fifa)<-str_replace_all(names(Fifa), c(" " = "." , "," = "" ))
imputed.data <- mice(Fifa)
imputed.data
Fifadata<-complete(imputed.data,2)
#FifadataNew <- Fifadata[complete.cases(Fifadata[ , "Crossing"]),]

#Transform varible
summary(powerTransform(cbind(Fifadata$WageNew, Fifadata$Overall,Fifadata$Age, Fifadata$Potential)~1))
sum(is.na(Fifadata))
dim(Fifadata)

#Early Try
kaggle<-lm(log(Fifadata$WageNew) ~ Fifadata$Overall^2  + Fifadata$Club)
summary(kaggle)

#Get rid of Outliers and bad leverage
hatval <- hatvalues(kaggle)
badleverage <- which(hatval > 2*3/length(hatval) & abs(rstandard(kaggle)) > 2)
NoBL <- Fifadata[-badleverage,]

#Late Try
kaggle2<-lm(log(NoBL$WageNew) ~ NoBL$Overall^2 + NoBL$Club + NoBL$International.Reputation)
summary(kaggle2)
anova(kaggle2)
#sums <- rowSums(FifadataNew[,47:80])

kaggle3<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential + 1/(Age^2),data=Fifadata)
summary(kaggle3)
anova(kaggle3)

#Output
names(FifaNoY)<-str_replace_all(names(FifaNoY), c(" " = "." , "," = "" ))

kaggle0<-lm(log(WageNew) ~ Overall^2 , data=Fifadata)
summary(kaggle0)
xsub <- exp(predict(kaggle0,FifaNoY))
x<- exp(predict(kaggle3, FifaNoY))
x<-ifelse(is.na(x), xsub, x)
write.csv(x, "sxc.csv")


kaggle4<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential 
            + Weak.Foot + Skill.Moves + Special + Weight + Height + Work.Rate 
            + Nationality + Real.Face + Position + 1/(Age^2) + Joined, data = NoBL)
summary(kaggle4)
anova(kaggle4)


kaggle5<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential 
            + Weak.Foot + Skill.Moves + Special + Weight + Height + Work.Rate 
            + Nationality + Real.Face + Position + 1/(Age^2) + Joined 
            + Contract.Valid.Until + Crossing + Finishing + ShortPassing 
            + HeadingAccuracy , data = NoBL)
summary(kaggle5)


pairs(~Overall+International.Reputation+Potential+Age+Weak.Foot+Crossing+Finishing+ShortPassing 
      +HeadingAccuracy+Volleys+Dribbling+Curve+FKAccuracy 
      +LongPassing,data=NoBL,
      main="Matrix plot")

#https://www.displayr.com/how-to-create-a-correlation-matrix-in-r/
#rcorr(as.matrix(NoBL[, c("Overall", "Potential")]))

cor_NoBL <- cor(NoBL[, c("Overall", "International.Reputation", "Potential", "Age", "Weak.Foot", 
                         "Crossing", "Finishing", "ShortPassing", "HeadingAccuracy", "Volleys", 
                         "Dribbling", "Curve", "FKAccuracy", "LongPassing")])
corrplot(cor_NoBL)


kaggle6<-lm(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential 
            + Weak.Foot + Skill.Moves + Special + Weight + Height + Work.Rate 
            + Nationality + Real.Face + Position + 1/(Age^2) + Joined 
            + Contract.Valid.Until + Crossing + Finishing + ShortPassing 
            + HeadingAccuracy + Volleys + Dribbling + Curve + FKAccuracy 
            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
            + Reactions + Balance + ShotPower + Jumping	+ Stamina	+ Strength 
            + LongShots + Aggression	+ Interceptions	+ Positioning	+ Vision 
            + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
            + GKDiving + GKHandling	+ GKKicking	+ GKPositioning	+ GKReflexes, data = NoBL)
summary(kaggle6)
anova(kaggle6)
cor(log(WageNew) ~ Overall^2 + Club + International.Reputation + Potential 
    + Weak.Foot + Skill.Moves + Special + Weight + Height + Work.Rate 
    + Nationality + Real.Face + Position + 1/(Age^2) + Joined 
    + Contract.Valid.Until + Crossing + Finishing + ShortPassing 
    + HeadingAccuracy + Volleys + Dribbling + Curve + FKAccuracy 
    + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
    + Reactions + Balance + ShotPower + Jumping	+ Stamina	+ Strength 
    + LongShots + Aggression	+ Interceptions	+ Positioning	+ Vision 
    + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
    + GKDiving + GKHandling	+ GKKicking	+ GKPositioning	+ GKReflexes)

pairs(~Overall+Potential+Age+Crossing + Finishing + ShortPassing 
      + HeadingAccuracy + Volleys + Dribbling + Curve + FKAccuracy 
      + LongPassing,data=NoBL,
      main="Simple Scatterplot Matrix")


#vector <- cor()

#corrplot(, method="circle")

# VIF NAN issue
# https://stats.stackexchange.com/questions/285722/vif-doesnt-show-up-values-for-categorical-variables
kaggle7<-lm(log(WageNew) ~ Overall^2 + Potential 
             + Special + 1/(Age^2) + Crossing + Finishing + ShortPassing 
            + HeadingAccuracy + Volleys + Dribbling + Curve + FKAccuracy 
            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
            + Reactions + Balance + ShotPower + Jumping	+ Stamina	+ Strength 
            + LongShots + Aggression	+ Interceptions	+ Vision 
            + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
            + GKDiving + GKHandling	+ GKKicking	+ GKPositioning	+ GKReflexes, data = NoBL)
summary(kaggle7)

vif(kaggle7)

temp <- anova(kaggle6)
#temp[order(temp$`F value`, decreasing = TRUE), ]
temp[order(temp$`Pr(>F)`, decreasing = FALSE), ]


par(mfrow = c(2,2))
plot(kaggle6)

scatterplot()


#Regression Model Accuracy Metrics: R-square, AIC, BIC, Cp and more
#http://www.sthda.com/english/articles/38-regression-model-validation/158-regression-model-accuracy-metrics-r-square-aic-bic-cp-and-more/
#https://www.r-bloggers.com/variable-selection-using-automatic-methods/

library(leaps)
temp <- regsubsets(log(WageNew) ~ Overall^2 + Potential + Special + 1/(Age^2) + Crossing + Finishing + ShortPassing 
                + HeadingAccuracy + Volleys + Dribbling + Curve + FKAccuracy 
                + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                + Reactions + Balance + ShotPower + Jumping	+ Stamina	+ Strength 
                + LongShots + Aggression	+ Interceptions	+ Vision 
                + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
                + GKDiving + GKHandling	+ GKKicking	+ GKPositioning	+ GKReflexes, 
                data = NoBL, method = "exhaustive")
rs <- summary(temp)
rs$adjr2
plot(1:8, rs$adjr2, xlab="Subset Size", ylab="Adjusted R-squared")
set1 <- lm(log(WageNew) ~ Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
           + HeadingAccuracy + Volleys + Dribbling, data = NoBL)
set2 <- lm(log(WageNew) ~ Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
           + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
           + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
           + Reactions, data = NoBL)
set3 <- lm(log(WageNew) ~ Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
           + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
           + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
           + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
           + LongShots + Aggression	+ Interceptions, data = NoBL)
set4 <- lm(log(WageNew) ~ Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
           + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
           + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
           + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
           + LongShots + Aggression	+ Interceptions + Vision 
           + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
           + GKDiving + GKHandling, data = NoBL)
set5 <- lm(log(WageNew) ~ Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
           + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
           + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
           + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
           + LongShots + Aggression	+ Interceptions + Vision 
           + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
           + GKDiving + GKHandling + GKKicking + GKPositioning	+ GKReflexes, data = NoBL)

# For set1 find AIC and BIC
# Getting the AIC value for the full model set1: k=2 means we are using AIC measure
set1_AIC <- extractAIC(set1, k=2)
set1_AIC
# Getting the AIC value for the full model set1: k=log(n) means we are using BIC measure
set1_BIC<-extractAIC(set1, k=log(length(NoBL$WageNew)))
set1_BIC
# For set2 find AIC and BIC
# Getting the AIC value for the full model set2: k=2 means we are using AIC measure
set2_AIC <- extractAIC(set2, k=2)
set2_AIC
# Getting the AIC value for the full model set2: k=log(n) means we are using BIC measure
set2_BIC<-extractAIC(set2, k=log(length(NoBL$WageNew)))
set2_BIC
# For set3 find AIC and BIC
# Getting the AIC value for the full model set3: k=2 means we are using AIC measure
set3_AIC <- extractAIC(set3, k=2)
set3_AIC
# Getting the AIC value for the full model set3: k=log(n) means we are using BIC measure
set3_BIC<-extractAIC(set3, k=log(length(NoBL$WageNew)))
set3_BIC
# For set4 find AIC and BIC
# Getting the AIC value for the full model set4: k=2 means we are using AIC measure
set4_AIC <- extractAIC(set4, k=2)
set4_AIC
# Getting the AIC value for the full model set4: k=log(n) means we are using BIC measure
set4_BIC<-extractAIC(set4, k=log(length(NoBL$WageNew)))
set4_BIC
# For set5 find AIC and BIC
# Getting the AIC value for the full model set5: k=2 means we are using AIC measure
set5_AIC <- extractAIC(set5, k=2)
set5_AIC
# Getting the AIC value for the full model set5: k=log(n) means we are using BIC measure
set5_BIC<-extractAIC(set5, k=log(length(NoBL$WageNew)))
set5_BIC
# Find summary for all sets
summary(set1)
summary(set2)
summary(set3)
summary(set4)
summary(set5)


# Getting set1 backward AIC and BIC from the approach based on backward selection
n1 <- length(set1$residuals)
set1_backAIC <- step(set1, direction = "backward", data = NoBL)
set1_backBIC <- step(set1, direction = "backward", data = NoBL, k = log(n1))

# Getting set2 backward AIC and BIC from the approach based on backward selection
n2 <- length(set2$residuals)
set2_backAIC <- step(set2, direction = "backward", data = NoBL)
set2_backBIC <- step(set2, direction = "backward", data = NoBL, k = log(n2))

# Getting set3 backward AIC and BIC from the approach based on backward selection
n3 <- length(set3$residuals)
set3_backAIC <- step(set3, direction = "backward", data = NoBL)
set3_backBIC <- step(set3, direction = "backward", data = NoBL, k = log(n3))

# Getting set4 backward AIC and BIC from the approach based on backward selection
n4 <- length(set4$residuals)
set4_backAIC <- step(set4, direction = "backward", data = NoBL)
set4_backBIC <- step(set4, direction = "backward", data = NoBL, k = log(n4))

# Getting set5 backward AIC and BIC from the approach based on backward selection
n5 <- length(set5$residuals)
set5_backAIC <- step(set5, direction = "backward", data = NoBL)
set5_backBIC <- step(set5, direction = "backward", data = NoBL, k = log(n5))


temp1 <- lm(log(WageNew) ~ 1, data = NoBL) 
# Getting set1 forward AIC and BIC from the approach based on forward selection
n1 <- length(set1$residuals)
set1_forwardAIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                       + HeadingAccuracy + Volleys + Dribbling), direction = "forward", data = NoBL)

set1_forwardBIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling), direction = "forward", data = NoBL, k = log(n))


# Getting set2 forward AIC and BIC from the approach based on forward selection
n2 <- length(set2$residuals)
set2_forwardAIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions), direction = "forward", data = NoBL)

set2_forwardBIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions), direction = "forward", data = NoBL, k = log(n2))


# Getting set3 forward AIC and BIC from the approach based on forward selection
n3 <- length(set3$residuals)
set3_forwardAIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
                                            + LongShots + Aggression	+ Interceptions), direction = "forward", data = NoBL)

set3_forwardBIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
                                            + LongShots + Aggression	+ Interceptions), direction = "forward", data = NoBL, k = log(n3))


# Getting set4 forward AIC and BIC from the approach based on forward selection
n4 <- length(set4$residuals)
set4_forwardAIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
                                            + LongShots + Aggression	+ Interceptions + Vision 
                                            + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
                                            + GKDiving + GKHandling), direction = "forward", data = NoBL)

set4_forwardBIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
                                            + LongShots + Aggression	+ Interceptions + Vision 
                                            + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
                                            + GKDiving + GKHandling), direction = "forward", data = NoBL, k = log(n4))


# Getting set5 forward AIC and BIC from the approach based on forward selection
n5 <- length(set5$residuals)
set5_forwardAIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
                                            + LongShots + Aggression	+ Interceptions + Vision 
                                            + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
                                            + GKDiving + GKHandling + GKKicking + GKPositioning	+ GKReflexes), direction = "forward", data = NoBL)

set5_forwardBIC <- step(temp1, scope = list(lower=~1, upper=~Overall^2 + Potential + Special + 1/(Age^2) + Crossing 
                                            + HeadingAccuracy + Volleys + Dribbling + + Curve + FKAccuracy 
                                            + LongPassing + BallControl + Acceleration + SprintSpeed + Agility 
                                            + Reactions + Balance + ShotPower + Jumping + Stamina	+ Strength 
                                            + LongShots + Aggression	+ Interceptions + Vision 
                                            + Penalties + Composure + Marking + StandingTackle + SlidingTackle 
                                            + GKDiving + GKHandling + GKKicking + GKPositioning	+ GKReflexes), direction = "forward", data = NoBL, k = log(n5))


