response <- c(7, 9, 34, 55, 16, 20, 40, 60, 8, 10, 32, 50, 18, 21, 44, 61, 8, 
              12, 35, 52, 15, 22, 45, 65, 6, 10, 30, 53, 15, 20, 41, 63)
library(DoE.base)
k <- 5
contrast <- contr.FrF2(2^(k))
colnames(contrast) <- c("A", "B", "AB", "C", "AC", "BC", "ABC","D", "AD", "BD", "ABD", "CD", "ACD", 
                        "BCD", "ABCD","E", "AE", "BE", "ABE", "CE", "ACE", "BCE", "ABCE","DE", 
                        "ADE", "BDE", "ABDE", "CDE", "ACDE", "BCDE", "ABCDE")
contrast
effect=t(response)%*%contrast/(16*1)
effect1

block <- contrast[, c("ABCDE")]
response[block==1] <- response[block==1]-20
response[block==1] <- response
da=data.frame(contrast, block, response)
model2 <- aov(response ~ factor(A) * factor(B) * factor(C) * factor(D) * factor(E) + factor(block), data = da)
summary(model2)