public class Address {

	@Override
	public String toString() {
		char splitter = '\n';
		StringBuilder res = new StringBuilder();
		res.append(lines);
		res.append(splitter);
		res.append(city);
		res.append(splitter);
		res.append(state);
		res.append(splitter);
		res.append(postalCode);
		res.append(splitter);
		res.append(countryCode);
		return res.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Address)) {
			return false;
		}
		Address otherAddress = (Address) obj;
		return lines.equals(otherAddress.lines) &&
				city.equals(otherAddress.city) &&
				state.equals(otherAddress.state) &&
				postalCode.equals(otherAddress.postalCode) &&
				countryCode.equals(otherAddress.countryCode);
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	/***************************
	 * All getters and setters *
	 ***************************/

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return countryCode;
	}

	public void setCountry(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getLines() {
		return lines;
	}

	public void setLines(String lines) {
		this.lines = lines;
	}

	/*************************************************************
	 * Below part of code is copied from the assignment document *
	 *************************************************************/

	private String city;
	private String state;
	private String postalCode;
	private String countryCode;
	private String lines;

	public Address() {}

	public Address(String city, String state, String postalCode, String countryCode, String lines) {
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.countryCode = countryCode;
		this.lines = lines;
	}

}
