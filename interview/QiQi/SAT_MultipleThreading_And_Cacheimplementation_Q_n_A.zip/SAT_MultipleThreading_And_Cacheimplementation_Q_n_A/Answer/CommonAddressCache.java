import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

public class CommonAddressCache {

	private final Database db;
	private final ConcurrentLruCache cache;

	public CommonAddressCache(Database db, int cacheSizeLimit) {
		if (cacheSizeLimit < 1) {
			throw new IllegalArgumentException("Cache size cannot be smaller than 1: " + cacheSizeLimit);
		}
		this.db = db;
		cache = new ConcurrentLruCache(cacheSizeLimit);
	}

	// parser should use this method to get Address
	public Address getAddress(Address key) {
		return cache.get(key);
	}

	// As assignment document requires, this method will:
	// If address find in DB, return it. Otherwise, return null
	public Address SearchDB(String lines, String city, String state, String postalCode, String countryCode) {
		return db.search(lines, city, state, postalCode, countryCode);
	}

	// The signature of this method is copied from the assignment document
	public Address getAddress(String lines, String city, String state, String postalCode, String countryCode) {
		Address addressUsedForSearch = new Address();
		addressUsedForSearch.setLines(lines);
		addressUsedForSearch.setCity(city);
		addressUsedForSearch.setState(state);
		addressUsedForSearch.setPostalCode(postalCode);
		addressUsedForSearch.setCountry(countryCode);
		return getAddress(addressUsedForSearch);
	}

	private Address commitNewAddressToDb(String lines, String city, String state, String postalCode, String countryCode) {
		return db.commitNewAddress(lines, city, state, postalCode, countryCode);
	}

	private class ConcurrentLruCache {

		private final ConcurrentMap<Address, Future<Address>> cache;
		private final SingleThreadLruCacheSizeController monitor;

		public ConcurrentLruCache(int cacheSizeLimit) {
			cache = new ConcurrentHashMap<>();
			monitor = new SingleThreadLruCacheSizeController(cacheSizeLimit, cache);
			Thread monitorThread = new Thread(monitor);
			monitorThread.start();
		}

		public Address get(Address key) {
			monitor.recordUsage(key);
			Future<Address> cached = cache.get(key);
			try {
				if (cached != null) {
					return cached.get();
				}
				final FutureTask<Address> task = new FutureTask<Address>(() -> {
					Address addressInDb = SearchDB(key.getLines(), key.getCity(),
							key.getState(), key.getPostalCode(), key.getCountry());
					if (addressInDb == null) {
						addressInDb = commitNewAddressToDb(key.getLines(), key.getCity(),
								key.getState(), key.getPostalCode(), key.getCountry());
					}
					return addressInDb;
				});
				Future<Address> oldCachedValue = cache.putIfAbsent(key, task);
				if (oldCachedValue != null) {
					cached = oldCachedValue;
				} else {
					task.run();
					cached = task;
				}
				return cached.get();
			} catch (InterruptedException | ExecutionException e) {
				cache.remove(key);
				// log error
				return null;
			}
		}

	}

	private class SingleThreadLruCacheSizeController implements Runnable {

		private final int sizeLimit;
		private final ConcurrentMap<Address, Future<Address>> cache;
		private final Queue<Address> concurrentQueue;
		private final Map<Address, DoubleLinkedListNode> nodeMap;
		private final DoubleLinkedListNode doubleLinkedListHead;
		private final DoubleLinkedListNode doubleLinkedListTail;

		public SingleThreadLruCacheSizeController(int cacheSizeLimit,
				ConcurrentMap<Address, Future<Address>> cache) {
			this.sizeLimit = cacheSizeLimit;
			this.cache = cache;
			this.concurrentQueue = new ConcurrentLinkedQueue<>();
			nodeMap = new HashMap<>();
			doubleLinkedListHead = new DoubleLinkedListNode();
			doubleLinkedListTail = new DoubleLinkedListNode();
			doubleLinkedListHead.next = doubleLinkedListTail;
			doubleLinkedListTail.next = doubleLinkedListHead;
		}

		public void recordUsage(Address key) {
			boolean isEmptyBeforeAdd = concurrentQueue.isEmpty();
			concurrentQueue.add(key);
			if (isEmptyBeforeAdd) {
				synchronized (concurrentQueue) {
					concurrentQueue.notify();
				}
			}
		}

		@Override
		public void run() {
			while (true) {
				while (!concurrentQueue.isEmpty()) {
					Address key = concurrentQueue.remove();
					DoubleLinkedListNode listNode = nodeMap.get(key);
					if (listNode != null) {
						moveNodeToHead(listNode);
					} else {
						addNewNode(key);
					}
				}
				synchronized (concurrentQueue) {
					if (concurrentQueue.isEmpty()) {
						try {
							concurrentQueue.wait();
						} catch (InterruptedException e) {
							// log error
						}
					}
				}
			}
		}

		private void moveNodeToHead(DoubleLinkedListNode node) {
			node.previous.next = node.next;
			node.next.previous = node.previous;
			node.previous = doubleLinkedListHead;
			node.next = doubleLinkedListHead.next;
			doubleLinkedListHead.next = node;
			node.next.previous = node;
		}

		private void addNewNode(Address key) {
			if (nodeMap.size() == sizeLimit) {
				removeLastNode();
			}
			DoubleLinkedListNode newNode = new DoubleLinkedListNode();
			nodeMap.put(key, newNode);
			newNode.value = key;
			newNode.previous = doubleLinkedListHead;
			newNode.next = doubleLinkedListHead.next;
			doubleLinkedListHead.next = newNode;
			newNode.next.previous = newNode;
		}

		private void removeLastNode() {
			DoubleLinkedListNode lastNode = doubleLinkedListTail.previous;
			lastNode.previous.next = doubleLinkedListTail;
			doubleLinkedListTail.previous = lastNode.previous;
			Address key = lastNode.value;
			cache.remove(key);
			nodeMap.remove(key);
		}

	}

	private class DoubleLinkedListNode {

		private DoubleLinkedListNode previous;
		private DoubleLinkedListNode next;
		private Address value;

	}

	/*************************************************************
	 * Below part of code is copied from the assignment document *
	 *************************************************************/

	public Address createAddress(List<String> streets, String city, String state, String postalCode,
			String countryCode) {
		Address address = new Address();
		// Set the information
		StringBuffer street = new StringBuffer();
		int streetSize = streets.size();
		for (int i = 0; i < streetSize; i++) {
			street.append(streets.get(i));
			if (i != streetSize - 1) {
				street.append("\n");
			}
		}
		address.setLines(street.toString());
		address.setCity(city);
		address.setState(state);
		address.setPostalCode(postalCode);
		address.setCountry(countryCode);
		return address;
	}

}
