public interface Database {

	/**
	 * Uses given information to search an address in the database.
	 * 
	 * @param lines
	 * @param city
	 * @param state
	 * @param postalCode
	 * @param countryCode
	 * @return	the <code>Address</code> found in the database, or <code>null</code> if not found
	 */
	Address search(String lines, String city, String state, String postalCode, String countryCode);

	/**
	 * Creates a new address in the database.
	 * @param address
	 */
	Address commitNewAddress(String lines, String city, String state, String postalCode, String countryCode);

}
