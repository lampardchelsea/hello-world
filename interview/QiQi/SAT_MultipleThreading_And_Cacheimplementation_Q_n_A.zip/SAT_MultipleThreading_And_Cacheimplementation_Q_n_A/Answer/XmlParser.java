import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XmlParser {

	private final CommonAddressCache cache;
	private final DocumentBuilder builder;

	public XmlParser(CommonAddressCache cache) throws ParserConfigurationException {
		this.cache = cache;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		// I cannot access to the "http://svcdev6.ariba.com/schemas/cXML/1.2.032/InvoiceDetail.dtd" in
		// the "sg invoice" XML file template, so I ignore this external DTD
		dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

		builder = dbf.newDocumentBuilder();
	}

	public List<Address> parse(String fileLocation) throws SAXException, IOException {
		Document document = builder.parse(new File(fileLocation));
		document.getDocumentElement().normalize();
		NodeList postalAddressList = document.getElementsByTagName("PostalAddress");
		int postalAddressListLength = postalAddressList.getLength();
		List<Address> result = new ArrayList<>(postalAddressListLength);
		for (int i = 0; i < postalAddressListLength; i++) {
			Node node = postalAddressList.item(i);
			if (node.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}
			Element element = (Element) node;
			List<String> streets = getAddressStreetsFromElement(element);
			String city = getOneAddressAttributeFromElement(element, "City");
			String state = getOneAddressAttributeFromElement(element, "State");
			String postalCode = getOneAddressAttributeFromElement(element, "PostalCode");
			String countryCode = getAddressCountryCodeFromElement(element);
			Address addressUsedForSearch = cache.createAddress(streets, city, state, postalCode, countryCode);
			Address addressObjInDb = cache.getAddress(addressUsedForSearch);
			if (addressObjInDb == null) {
				// there is an error occurred
				// if needed, log this error
			} else {
				result.add(addressObjInDb);
			}
		}
		return result;
	}

	private static List<String> getAddressStreetsFromElement(Element element) {
		NodeList streetList = element.getElementsByTagName("Street");
		int streetListSize = streetList.getLength();
		List<String> result = new ArrayList<>(streetListSize);
		for (int i = 0; i < streetListSize; i++) {
			Node node = streetList.item(i);
			if (node.getNodeType() != Node.ELEMENT_NODE) {
				continue;
			}
			String street = node.getTextContent();
			result.add(street);
		}
		return result;
	}

	private static String getOneAddressAttributeFromElement(Element element, String attributeName) {
		NodeList list = element.getElementsByTagName(attributeName);
		Element first = getFirstElementFromNodeList(list);
		return first != null ? first.getTextContent() : "";
	}

	private static String getAddressCountryCodeFromElement(Element element) {
		NodeList countryList = element.getElementsByTagName("Country");
		Element firstCountryElement = getFirstElementFromNodeList(countryList);
		if (firstCountryElement == null) {
			return "";
		}
		String isoCountryCode = firstCountryElement.getAttribute("isoCountryCode");
		return isoCountryCode != null ? isoCountryCode : "";
	}

	private static Element getFirstElementFromNodeList(NodeList list) {
		int listLength = list.getLength();
		for (int i = 0; i < listLength; i++) {
			Node node = list.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				return (Element) node;
			}
		}
		return null;
	}

}
