There are 7 APIs in our project.
config_db.php used to connect to our database.

API files:
authorize_user.php
comment_edit.php
comment_get_for_a_device.php
comment_get_for_a_user.php
plugin_add.php
plugin_delete.php
plugin_get_list.php
