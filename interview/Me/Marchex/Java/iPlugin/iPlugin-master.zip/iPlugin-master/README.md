iPlugin
=======

This is a project for NTx Apps Challenge.
Source code for Android Client and Server.
Based on Secret Contract Document, we can not share the code for Gemalto Concept Board.

Project Description:
We are connecting the app with the Gemalto Concept Board to make an intelligent plugs that can monitor and save your energy at home or office. it's under the Energy Vertical. We are using both Gemalto Concept Board AND SensorLogic Platform to simulate the IoT Challenge Horizontal.

We believe there are huge waste in energy consumption. We want to develop the app and the board that can intelligent enough to detect the energy usage and be able to send the text message or alert to notify the user. We want the users to understand how much and where they spend the electricity bills.

Project Goals:
(1) Monitor and reduce the energy consumption especially the electricity usage for residential and commercial.
(2) Commercialize the concert to make a consumer product where every home and business can save energy and money.
(3) Implement the idea using the Gemalto Board and platform to simulate the actual monitoring and saving.

More Details: http://collabfinder.com/project/991/ntx-app-challenge-iplugin

Promotional Video: http://youtu.be/X4c9NWIz6js

NTx Apps Challenge: http://www.ntxappschallenge.com/

We moved the "Secret Key" in Android part for login to SensorLogic Platform. And also we moved user info for database. If you want to get data using our account, please contact us.
