vowels = ['a','e','i','o','u']
#words = "Milliways"
words = input("Provide a word to search for vowels: ")
found = []
for letter in words:
    if letter in vowels:
        if letter not in found:
            found.append(letter)
for vowel in found:
    print(vowel)
