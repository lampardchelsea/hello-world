# grok_sdi_educative
