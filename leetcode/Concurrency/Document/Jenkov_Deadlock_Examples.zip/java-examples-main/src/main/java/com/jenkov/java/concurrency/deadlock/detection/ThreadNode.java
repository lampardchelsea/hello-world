package com.jenkov.java.concurrency.deadlock.detection;

public class ThreadNode {

    public LockNode waitingFor = null;
    public Thread   thread     = null;





}
