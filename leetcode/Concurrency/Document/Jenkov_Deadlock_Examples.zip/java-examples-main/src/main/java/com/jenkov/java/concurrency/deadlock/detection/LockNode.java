package com.jenkov.java.concurrency.deadlock.detection;

public class LockNode {

    public ThreadNode lockedBy = null;

}
