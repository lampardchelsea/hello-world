/*
 * GNU License.
 */
package unissexbathroomlock.person;

/**
 * Sexes.
 *
 * @author Breno & Patricia
 * @version 29/05/2017
 */
public enum Sex {
    NONE, MAN, WOMAN
}
