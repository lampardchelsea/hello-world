package com.sergeyvolkodav.unisexbathroom;

public enum Gender {
    MEN, FEMALE, NONE
}
